from flask import Flask, render_template, request
from waitress import serve  # <-- Added this import

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/check', methods=['POST'])
def check():
    url = request.form['url']
    if 'free' in url or 'win' in url or 'click' in url:
        result = '⚠️ Phishing Suspected!'
    else:
        result = '✅ Looks Safe!'
    return render_template('index.html', result=result)

@app.route('/myth-buster')
def myth_buster():
    return render_template('myth_buster.html')

@app.route('/tips')
def tips():
    return render_template('tips.html')

if __name__ == '__main__':
    serve(app, host='0.0.0.0', port=5000)  # <-- Replaced app.run() with serve()
